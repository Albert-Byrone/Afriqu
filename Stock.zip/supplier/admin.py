from django.contrib import admin
from .models import Supplier

admin.site.register(Supplier)