from django.apps import AppConfig


class SupplierConfig(AppConfig):
    name = 'supplier'
