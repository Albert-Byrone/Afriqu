from django.apps import AppConfig


class MaterialsConfig(AppConfig):
    name = 'materials'
